package com.example.joeclancyproject2option1;

import org.mindrot.jbcrypt.BCrypt;

public class PasswordUtils {

    // Hash a password with a salt
    public static String hashPassword(String password) {
        return BCrypt.hashpw(password, BCrypt.gensalt(12));
    }

    // Check if a password matches the hashed password
    public static boolean checkPassword(String password, String hashedPassword) {
        return BCrypt.checkpw(password, hashedPassword);
    }
}