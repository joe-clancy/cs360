package com.example.joeclancyproject2option1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name
    public static final String DATABASE_NAME = "AppDatabase.db";

    // User table information
    public static final String USER_TABLE_NAME = "user_table";
    public static final String USER_COL_1 = "ID";
    public static final String USER_COL_2 = "USERNAME";
    public static final String USER_COL_3 = "PASSWORD";

    // Inventory table information
    public static final String INVENTORY_TABLE_NAME = "inventory_table";
    public static final String INVENTORY_COL_1 = "ITEM_ID";
    public static final String INVENTORY_COL_2 = "ITEM_NAME";
    public static final String INVENTORY_COL_3 = "ITEM_QUANTITY";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create User Table
        db.execSQL("CREATE TABLE " + USER_TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT, PASSWORD TEXT)");

        // Create Inventory Table
        db.execSQL("CREATE TABLE " + INVENTORY_TABLE_NAME + " (ITEM_ID INTEGER PRIMARY KEY AUTOINCREMENT, ITEM_NAME TEXT, ITEM_QUANTITY INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + INVENTORY_TABLE_NAME);
        onCreate(db);
    }

    // User table CRUD operations
    public boolean insertUser(String username, String password) {
        // get hash of password
        String hashedPassword = PasswordUtils.hashPassword(password);
        SQLiteDatabase db = this.getWritableDatabase();
        // create new user record
        ContentValues contentValues = new ContentValues();
        contentValues.put(USER_COL_2, username);
        contentValues.put(USER_COL_3, hashedPassword);
        long result = db.insert(USER_TABLE_NAME, null, contentValues);
        return result != -1; // returns true if insert is successful
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + USER_TABLE_NAME + " WHERE USERNAME = ?", new String[]{username});
        if (cursor.moveToFirst()) {
            String storedHash = cursor.getString(cursor.getColumnIndexOrThrow(USER_COL_3));
            return PasswordUtils.checkPassword(password, storedHash); // returns true if password hashes match
        }
        return false;
    }
    // Inventory Table CRUD Operations
    public boolean insertInventoryItem(String itemName, int itemQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        // create new item record
        ContentValues contentValues = new ContentValues();
        contentValues.put(INVENTORY_COL_2, itemName);
        contentValues.put(INVENTORY_COL_3, itemQuantity);
        long result = db.insert(INVENTORY_TABLE_NAME, null, contentValues);
        return result != -1; // returns true if insert is successful
    }

    public Cursor getAllInventoryItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + INVENTORY_TABLE_NAME, null);
    }

    public boolean updateInventoryItem(int itemId, String itemName, int itemQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(INVENTORY_COL_2, itemName);
        contentValues.put(INVENTORY_COL_3, itemQuantity);
        int result = db.update(INVENTORY_TABLE_NAME, contentValues, "ITEM_ID = ?", new String[]{String.valueOf(itemId)});
        return result > 0;
    }

    public boolean deleteInventoryItem(int itemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(INVENTORY_TABLE_NAME, "ITEM_ID = ?", new String[]{String.valueOf(itemId)});
        return result > 0;
    }
}