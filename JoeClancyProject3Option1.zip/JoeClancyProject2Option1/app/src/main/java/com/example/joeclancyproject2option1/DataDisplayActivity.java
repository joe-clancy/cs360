package com.example.joeclancyproject2option1;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.database.Cursor;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class DataDisplayActivity extends AppCompatActivity {


    private TableLayout tableLayout;
    private FloatingActionButton addItemFab;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // Initialize views
        tableLayout = findViewById(R.id.tableLayout);
        addItemFab = findViewById(R.id.addItemFab);
        dbHelper = new DatabaseHelper(this);

        // Load data from the database
        loadInventoryItems();

        // Set up the Add Item FAB click listener
        addItemFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent to go to DataAddActivity
                Intent intent = new Intent(DataDisplayActivity.this, DataAddActivity.class);
                startActivity(intent);
            }
        });

        // Set up settings button
        ImageButton settingsButton = findViewById(R.id.settingsButton);
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent to go to the SMS Notification activity
                Intent intent = new Intent(DataDisplayActivity.this, SMSNotificationActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Reload the inventory items when the activity is resumed
        loadInventoryItems();
    }

    private void loadInventoryItems() {
        // Clear existing rows
        tableLayout.removeViews(1, tableLayout.getChildCount() - 1); // Keep the header row

        // Retrieve items from the database
        Cursor cursor = dbHelper.getAllInventoryItems();
        if (cursor != null && cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                addItemToTable(cursor.getString(1), cursor.getInt(2), cursor.getInt(0)); // Name, Quantity, ID
            }
            cursor.close();
        } else {
            // No items found
            Toast.makeText(this, "No inventory items found", Toast.LENGTH_SHORT).show();
        }
    }

    private void addItemToTable(String itemName, int itemQuantity, int itemId) {
        TableRow row = new TableRow(this);

        // Column 1, item name
        TextView nameTextView = new TextView(this);
        nameTextView.setText(itemName);
        nameTextView.setPadding(8, 8, 8, 8);
        if (itemQuantity < 1) nameTextView.setBackgroundColor(Color.parseColor("#FFCCBB"));

        // Column 2, item quantity
        TextView quantityTextView = new TextView(this);
        quantityTextView.setText(String.valueOf(itemQuantity));
        if (itemQuantity < 1) quantityTextView.setBackgroundColor(Color.parseColor("#FFCCBB"));
        quantityTextView.setPadding(8, 8, 8, 8);

        // Column 3, more options button
        ImageButton moreOptionsButton = new ImageButton(this);
        moreOptionsButton.setImageResource(R.drawable.ic_more_vert);
        moreOptionsButton.setBackgroundResource(android.R.color.transparent);
        moreOptionsButton.setPadding(8, 8, 8, 8);

        // Set the click listener for the more options button
        moreOptionsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMoreOptions(itemId, itemName, itemQuantity);
            }
        });

        // Assemble new row
        row.addView(nameTextView);
        row.addView(quantityTextView);
        row.addView(moreOptionsButton);

        tableLayout.addView(row);
    }

    private void showMoreOptions(int itemId, String itemName, int itemQuantity) {
        // Intent to go to the Data Edit Activity
        Intent intent = new Intent(DataDisplayActivity.this, DataEditActivity.class);
        intent.putExtra("ITEM_ID", itemId);
        intent.putExtra("ITEM_NAME", itemName);
        intent.putExtra("ITEM_QUANTITY", itemQuantity);
        startActivity(intent);
    }
}